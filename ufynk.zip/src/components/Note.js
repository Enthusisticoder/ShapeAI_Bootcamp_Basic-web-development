import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>JavaScript and React.js</h1>
      <p>It was an amazing bootcamp taken up by Shaurya Sinha Sir.JavaScript, React.js,HTML was covered from scratch. It was really an Eye openning session.Thank you so much.</p>
    </div>
  );
}

export default Note;